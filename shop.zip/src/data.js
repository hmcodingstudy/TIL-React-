

let data = [
    {
      id : 0,
      title : "Hold Ring",
      content : "Born in France",
      price : 87300,
      img: "https://cdn.amondz.com/product/66851/resize/mainImg/PSI_836655.jpeg?v=1670343653920"
    },
  
    {
      id : 1,
      title : "double layer necklace",
      content : "Born in Seoul",
      price : 59400,
      img: "https://cdn.amondz.com/product/32201/resize/mainImg/PSI_315447.jpeg?v=1606101369214"
    },
  
    {
      id : 2,
      title : "14K 트리플 시그니티 귀걸이",
      content : "Born in the States",
      price : 115200,
      img: "https://cdn.amondz.com/product/58646/resize/mainImg/PSI_602452.jpeg?v=1646716439354"
    }
  ] 

export default data;